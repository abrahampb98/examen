const config = {
    DB_URL: 'mongodb+srv://ups:ups2020@cluster0.pjyad.mongodb.net/tienda?retryWrites=true&w=majority',
    PUERTO: 3000
}

module.exports = config